---
layout: post
title: Alaska, All the Way to North (Part 1)
subtitle: Flying all the way to north from Syracuse via Seattle, we finally reach Anchorage, which is the first stop during our one-week-long stay in the northmost state of America, Alaska. Starting from here, we will explore around the city, drive along AK-1 S and State Hwy 9 to Seward looking forward to cat...
date:       2018-04-10 12:00:00
author:     "Helffor"
header-img: "assets/owner/blog/header/post-bg-01.jpg"
thumbnail: /assets/owner/blog/thumbs/thumb01.png
tags: [tag-name-one, tag-name-two]
category: [cat03]
comments: false
share: false
gallery1: 
  - image_path: /assets/owner/blog/galleries/g01/bg1.jpg
    image-caption: IMAGE TITLE
    image-copyright: © MADness
  - image_path: /assets/owner/blog/galleries/g01/bg2.jpg
    image-caption: IMAGE TITLE
    image-copyright: © MADness
  - image_path: /assets/owner/blog/galleries/g01/bg3.jpg
    image-caption: IMAGE TITLE
    image-copyright: © MADness 
gallery2: 
  - image_path: /assets/owner/blog/galleries/g02/bg1.jpg
    image-caption: IMAGE TITLE
    image-copyright: © MADness
  - image_path: /assets/owner/blog/galleries/g02/bg2.jpg
    image-caption: IMAGE TITLE
    image-copyright: © MADness
  - image_path: /assets/owner/blog/galleries/g02/bg3.jpg
    image-caption: IMAGE TITLE
    image-copyright: © MADness 
---

<p> Flying all the way to north from Syracuse via Seattle, we finally reach Anchorage, which is the first stop during our one-week-long stay in the northmost state of America, Alaska. Starting from here, we will explore around the city, drive along AK-1 S and State Hwy 9 to Seward looking forward to catching a glimpse of whales and glaciers in the Resurrection Bay, search the highest peak of North America in Denali National Park, hunt northern lights in the outskirts of Fairbanks, and enjoy the stunning scenery from up above in our flight back to Anchorage. </p>

<p> Add as many paragraphs amongst your galleries as you want. </p>


           {%comment%} Gallery {%endcomment%}
			
{% include subgallery.html id="gallery1" %}

<!-- end of GALLERY __ -->

<p> Add as many galleries as you want, including as many photos as you want. Simply edit the <b>FRONT MATTER</b> of the post, adding the corresponding <b>path</b>, <b>caption</b> and <b>copyright</b> info for each one of your photos. </p>

           {%comment%} Gallery {%endcomment%}
			
{% include subgallery.html id="gallery2" %}

<!-- end of GALLERY __ -->

		

###### Image Source: [UNSPLASH](https://unsplash.com/photos/j0g8taxHZa0)
